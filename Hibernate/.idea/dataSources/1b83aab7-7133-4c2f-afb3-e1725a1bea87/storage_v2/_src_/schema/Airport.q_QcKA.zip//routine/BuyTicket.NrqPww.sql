create
    definer = wage@localhost procedure BuyTicket(IN departure_town varchar(50), IN arrival_town varchar(50),
                                                 IN company_name varchar(50), IN client_id int)
begin
declare flight_id,departure_town_ID,arrival_town_ID,company_ID int;
set departure_town_ID = (select id from Towns where name like departure_town);
set arrival_town_ID = (select id from Towns where name like arrival_town);
set company_ID = (select id from Companies where name like company_name);
set flight_id = (select id from Flights where
departure_town_id = departure_town_ID
and
arrival_town_id = arrival_town_ID
and 
company_id = company_ID);
update Clients set cash = 
cash - (select price from Flights where id = flight_id);
update Flights_Planes set seat_num = seat_num -1;
insert Orders values(1,client_id,flight_id);
end;

